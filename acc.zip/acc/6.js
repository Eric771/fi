const { Client } = require('discord.js-selfbot-v13');
const { joinVoiceChannel } = require("@discordjs/voice");
const time = [25000, 20000,15000];
const client = new Client({ checkUpdate: true });

const config = require(`${process.cwd()}/config.json`);

client.on('ready', async () => {
    console.log(`self bot ruuning as ${client.user.tag}!`);

    await joinVC(client, config);
});
client.on('voiceStateUpdate', async (oldState, newState) => {
    const oldVoice = oldState.channelId;
    const newVoice = newState.channelId;

    if (oldVoice === newVoice)  {
                    setInterval(async () => {
                    if (oldState.member.id === client.user.id);
                    const guild = client.guilds.cache.get(`1065753106966650930`);
                    const voiceChannel = guild.channels.cache.get(`1202962814122332190`);
                    const connection = joinVoiceChannel({
                        channelId: voiceChannel.id,
                        guildId: guild.id,
                        adapterCreator: guild.voiceAdapterCreator,
                        selfDeaf: false,
                        selfMute: true
                    });
                }, 300 * 1000); 
                }
    if (oldVoice !== newVoice)  {
                    setInterval(async () => {
                    if (oldState.member.id === client.user.id);
                    const guild = client.guilds.cache.get(config.Guild);
                    const voiceChannel = guild.channels.cache.get(config.Channel);
                    const connection = joinVoiceChannel({
                        channelId: voiceChannel.id,
                        guildId: guild.id,
                        adapterCreator: guild.voiceAdapterCreator,
                        selfDeaf: false,
                        selfMute: true
                    });
                }, 480 * 1000); 
                }
            });
client.login(config.Token6);
// Copyright by sivvv0
async function joinVC(client, config) {
    const guild = client.guilds.cache.get(config.Guild);
    const voiceChannel = guild.channels.cache.get(config.Channel);
    const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: true
    });
}
client.on('messageCreate', message => {
    const content = message.content.toLocaleLowerCase()
    if (message.content === 'عيالي')
    if (message.author.id === '1076128293721489418','1183698133193085021','886339726171312138','1151709671971897364','764205712536371232','268559448992120832')
    if(message.channel.id === '1201155513954615316') {
      setTimeout(() => {
        message.reply("هلا دادي");
    }, time[Math.floor(Math.random() * time.length)]);
    }
});
client.on('messageCreate', message => {
    if (message.author.id === '1106752869874552842') return
    if(message.channel.id === '1192438841643114517') {
      setTimeout(() => {
        message.react('<:Emaj6:1177191092379197510>')//  <:Emaj6:1177191092379197510>
    }, 70 * 1000);
    }
    });